function loadDoc() {
    $("#actor-list").html("");
    const url = new URL(window.location.href);
    $.ajax({
        type: 'GET',
        url: url.searchParams.has("sortType")?"/movies/sort/" + url.searchParams.get("sortType") + "/" + url.searchParams.get("sortBy"):"/movies/sort/id/desc",
        success: function (result) {
            tab(result);
        },
        error: function (err) {
        console.log("err", err);
        }
    });
    
}

function deleteMovie(id) {
    $.ajax({
        type:"DELETE",
        url:"/movies/"+id,
        success:function(result) {
            loadDoc();
        },
    });
}

function editMovie(id) {
    location.href="/add_movie?id="+id;
}
function addActor(id) {
    location.href="/add_actor?id="+id;
}
function deleteActor(movieId, actorName) {
    console.log(actorName, movieId);
    $.ajax({
        type:"DELETE",
        url:"/movies/"+movieId + "/actors/"+actorName,
        success:function(result) {
            loadDoc();
        },
    });
}
function doSort(name) {
    const url = new URL(window.location.href);
    let sortBy = url.searchParams.get("sortBy") == "asc" ? "desc":"asc";
    window.location.href= "/list?sortType=" + name + "&sortBy=" + sortBy;
}
function tab(data){
    let size = data.length;
    // let edit_ajax = 'console.log(id_val)';
    let str = "";
    
    
    for(let i = 0; i < size; i++)
    {   
        str = str + "<tr>";
        str = str + "<td>" + data[i][1]["id"] +"</td>";
        str = str + "<td>" + data[i][1]["name"] +"</td>";
        str = str + "<td>" + data[i][1]["photo"] +"</td>";
        str = str + "<td>" + data[i][1]["rating"] +"</td>";
        str = str + "<td>" + data[i][1].distribution.from +"</td>";
        str += "<td>";
        str += "<ul class='list-group'>";
        if(data[i][1]["actors"]!=undefined) {
            for(let j = 0; j < data[i][1]["actors"].length; j ++) {
                str += "<li class='list-group-item'>" + data[i][1]["actors"][j]["name"] + "," +data[i][1]["actors"][j]["photo"]+ "," +data[i][1]["actors"][j]["site"];
                str += "<button class='btn btn-danger' onclick='deleteActor(\"" + data[i][1]["id"] + "\",\"" + data[i][1]["actors"][j]["name"] + "\")'>Remove</button>";
                str += "</li>";
                
            }
        }
        str += "</ul>";
        
        str += "</td>";
        str += "<td>" + data[i][1]["type"] +"</td>";
        str += "<td>" + (data[i][1]["seasons"] == undefined? "": data[i][1]["seasons"]) +"</td>";
        str += "<td>" + (data[i][1]["episodes"] == undefined? "": data[i][1]["episodes"]) +"</td>";
        str += "<td>";
        str += "<button class='btn btn-danger' onclick='deleteMovie(\"" + data[i][1]["id"] + "\")'>Remove</button>";
        str += "<button class='btn btn-success' onclick='editMovie(\"" + data[i][1]["id"] + "\")'>Edit</button>";
        str += "<button class='btn btn-warning' onclick='addActor(\"" + data[i][1]["id"] + "\")'>Add Actor</button>";
        str += "<button class='btn btn-primary' onclick='viewActor(\"" + data[i][1]["id"] + "\")'>View Actor</button>";
        str+= "</td></tr>";
    }
    let tableToAdd = $(str);
    $("#movie-list").html(tableToAdd);
    
}

$("document").ready(loadDoc);