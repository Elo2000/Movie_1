
$(document).ready(function () {
    
  const url = new URL(window.location.href);
  if (url.searchParams.has("id") && url.href.includes("add_movie")) {
    
  console.log(url.searchParams.get("id"));
    $.ajax({
      type:"get",
      url:"/movies/"+url.searchParams.get("id"),
      success:function(result) {
        console.log(result);
        $("#id").val(result.id);
        $("#name").val(result.name);
        $("#photo").val(result.photo);
        $("#director").val(result.director);
        $("#date_from").val(result.distribution.from);
        $("#type").val(result.type);
        if(result.type == "SERIES") {
          $("#season-group").css("display","block");
          $("#episode-group").css("display","block");
        }
        $("#rating").val(result.rating);
        $("#seasons").val(result.seasons);
        $("#episodes").val(result.episodes);
      },
  });
  }

  $("#type").change(function(event) {
    const type = $("#type").val();
    if(type == "MOVIE") {
      $("#season-group").css("display","none");
      $("#episode-group").css("display","none");
    }
    if(type == "SERIES") {
      $("#episode-group").css("display","block");
      $("#season-group").css("display","block");
    }
  });
  $('#saveBtn').click(function(event) {
    if(!$("#movie_form").valid()) return;

    const data = JSON.stringify({
        "id":$("#id").val(),
        "name":$("#name").val(),
        "photo":$("#photo").val(),
        "director":$("#director").val(),
        "distribution":{
          "from":$("#date_from").val() },
        "type":$("#type").val(),
        "rating":$("#rating").val(),
        "seasons":$("#type").val() == "SERIES" ?$("#seasons").val():"",
        "episodes":$("#type").val() == "SERIES" ?$("#episodes").val():""
    })
    if(url.searchParams.has("id")) {
      $.ajax({
        type:"PUT",
        url:"/movies/" + url.searchParams.get("id"),
        contentType: 'application/json',
        data:data,
        processData: false,            
        // dataType: 'json', // what type of data do we expect back from the server
        encode: true,
        success: function( data, textStatus, jQxhr ){
            console.log(data);
            location.href = "/list";

        },
        error: function( jqXhr, textStatus, errorThrown ){
            console.log( errorThrown );
        }
      });
    }
    else {
      $.ajax({
        type:"POST",
        url:"/movies",
        contentType: 'application/json',
        data:data,
        processData: false,            
        // dataType: 'json', // what type of data do we expect back from the server
        encode: true,
        success: function( data, textStatus, jQxhr ){
            console.log(data);
            location.href = "/list";

        },
        error: function( jqXhr, textStatus, errorThrown ){
            console.log( errorThrown );
        }
      });
    }
    event.preventDefault();
  });
    
  $("#add_actorBtn").click(function(event) {

    $.ajax({
      type:"POST",
      url:"/movies/"+url.searchParams.get("id") +"/actors",
      contentType: 'application/json',
      data:JSON.stringify({
        "name":$("#name").val(),
        "photo":$("#photo").val(),
        "site":$("#site").val(),
      }),
      success: function( data, textStatus, jQxhr ){
        console.log(data);
        location.href = "/list";

      },
      error: function( jqXhr, textStatus, errorThrown ){
          console.log( errorThrown );
      }
    })
    event.preventDefault();
  })
    
});
