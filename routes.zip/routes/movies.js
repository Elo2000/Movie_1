const fs = require('fs');

// variables
const dataPath = './data/movies.json';

// helper methods
const readFile = (callback, returnJson = false, filePath = dataPath, encoding = 'utf8') => {
    fs.readFile(filePath, encoding, (err, data) => {
            if (err) {
                console.log(err);
            }
            callback(returnJson ? JSON.parse(data) : data);
       });
};

const writeFile = (fileData, callback, filePath = dataPath, encoding = 'utf8') => {
        fs.writeFile(filePath, fileData, encoding, (err) => {
            if (err) {
                console.log(err);
            }

            callback();
        });
    };

const compareStrings = (a, b) => {
    // Assuming you want case-insensitive comparison
    a = a[1].id.toLowerCase();
    b = b[1].id.toLowerCase();
    return (a < b) ? -1 : (a > b) ? 1 : 0;
}

const compareDates = (a, b) =>{
    var dateA = new Date(a[1].distribution.from), dateB = new Date(b[1].distribution.from)
	return dateA - dateB
}
const compareRatings = (a, b) =>{
	a = parseInt(a[1].rating);
    b = parseInt(b[1].rating);
    return (a < b) ? -1 : (a > b) ? 1 : 0;
}
const compareName = (a, b) =>{
	a = a[1].name.toLowerCase();
    b = b[1].name.toLowerCase();;
    return (a < b) ? -1 : (a > b) ? 1 : 0;
}


module.exports = {
    
    /**
     * @name index
     * @param {*} req 
     * @param {*} res 
     * @description List Movies.
     * @returns array of movies
     */
    index: function (req, res) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) {
                console.log(err);
                res.sendStatus(500);                 
            }
            else{
                var obj = JSON.parse(data);
                var arr = Object.entries(obj);
                //var sorted = arr.sort(compareStrings);
                res.send(arr);
            }
        });
    },
    /**
     * @name getMovies
     * @param {*} sortType - can ben name, rating, date
     * @default sortType = null
     * @description READ all of movies - sorting
     * @returns sorted array of movies
     */
    getMovies: function (req, res) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) {
                console.log(err);
                res.sendStatus(500);                 
            }
            else{
                var obj = JSON.parse(data);
                var arr = Object.entries(obj);
                var sorted = arr;
                if(req.params.sortType == "name") { // sort by name of movie
                    sorted = arr.sort(compareName);
                }
                else if(req.params.sortType=="rating") { // sort by rating of movie
                    sorted = arr.sort(compareRatings);
                }
                else if(req.params.sortType=="date") { // sort by distribution date of movie
                    sorted = arr.sort(compareDates);
                }
                if(req.params.sortBy=="asc")
                    sorted = sorted.reverse();
                res.send(sorted);
            }
        });
    },
    /**
     * @name getMovie
     * @param {*} id - movie id
     * @description get a movie by id
     * @returns movie object by id.
     */
    getMovie: function (req, res) {
        fs.readFile(dataPath, 'utf8', (err, data) => {
            if (err) {
                console.log(err);
                res.sendStatus(500);                 
            }
            else{
                const Id = req.params["id"];
                var obj = JSON.parse(data);
                if(!obj[Id]){
                    res.status(400).send(`No such tour`);
                    return;
                }
                res.send(obj[Id]);
            }
        });
    },
    /**
     * @name createMovie
     * @param {*} req - movie object
     * @description create a new movie
     * @returns string- new movie added.
     */
    createMovie: function (req, res) {

        readFile(data => {
            // add the new user
            res.setHeader("Access-Control-Allow-Origin", '*'); // set cors header
            const obj = req.body;
            if(!obj.id || !obj.name || !obj.photo || !obj.director || 
                !obj.distribution.from || !obj.type || !obj.rating){
                    res.status(400).send('Missing args.');
                    return;
            }
            data[req.body.id] = req.body;

            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send('new Movie added');
            });
        },
            true);
    },
    /**
     * @name addActorToMovie
     * @param {*} id - movie id
     * @description create a actor to a movie given by id
     * @returns string- new actor added.
     */
    
    addActorToMovie: function (req, res) {
        readFile(data => {
            // add the new site
            const Id = req.params["id"];
            const obj = req.body;
            if(!data[Id]){
                res.status(400).send('No such Actor');
                return;
            }
            if(!data[Id].actors){
                data[Id].actors = [];
                data[Id].actors.push({...obj});
            }else{
                for(var i = 0; i < data[Id].actors.length; i++){
                    if(data[Id].actors[i].name == obj.name){
                        res.status(400).send('Already created');
                        return;
                    }
                }
                data[Id].actors.push({...obj});
            }
            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send('new site added');
            });
        },
            true);
},
    /**
     * @name updateMovie
     * @param {*} id - movie id
     * @description update a movie by id
     * @returns string- movie id updated.
     */
    updateMovie: function (req, res) {

        readFile(data => {

            // add the new user
            const Id = req.params["id"];
            if(!data[Id]){
                res.status(400).send('No such Movie');
                return;
            }
            const obj = req.body;
            
            data[Id] = req.body;
            if(obj.type == "MOVIE") {
                delete data[Id].seasons;
                delete data[Id].episodes;
            }

            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send(`movie id:${Id} updated`);
            });
        },
            true);
    },
    /**
     * @name deleteMovie
     * @param {*} id - movie id
     * @description delete a movie by id
     * @returns string- movie id removed.
     */
    deleteMovie: function (req, res) {

        readFile(data => {

            const Id = req.params["id"];
            if(!data[Id]){
                res.status(400).send('No such Movie');
                return;
            }
            delete data[Id];
            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send(`Movie id:${Id} removed`);
            });
        },
            true);
    },
    /**
     * @name deleteActorFromMovie
     * @param id - movie id
     * @param name - actor name
     * @description delete an actor from a movie by given id
     * @returns string- movie id actor name removed.
     */
    deleteActorFromMovie:function(req, res) {
        readFile(data => {

            // delete the site
            const Id = req.params["id"];
            const actor_name = req.params["name"];
            if(!data[Id]){
                res.status(400).send('No such Movie');
                return;
            }
            if(actor_name == null){
                res.status(400).send('Wrong arguments');
                return;
            }
            var found = false;
            for(var i = 0; i < data[Id].actors.length; i++){ // find a matching actor name from movie actors array given by id.
                if(data[Id].actors[i].name == actor_name){
                    delete data[Id].actors[i];
                    found = true;
                    if(data[Id].actors.length == 1)
                        delete data[Id].actors;
                    else
                        data[Id].actors = data[Id].actors.filter(name => name !== null)
                    break;
                }
            }
            if(!found){
                res.status(400).send('No such Actor');
                return;
            }
            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send(`movie id:${Id} actor name:${actor_name} removed`);
            });
        },
            true);
    }
    
};